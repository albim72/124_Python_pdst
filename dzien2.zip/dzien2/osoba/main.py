class Osoba:
	
	kolor_oczu = "niebieski"
	
	def __init__(self,imie,wiek,waga,wzrost):
		self.imie = imie
		self.wiek = wiek
		self.waga = waga
		self.wzrost = wzrost
		self.info()
		
	def info(self):
		print("tworzenie nowej instancji klasy Osoba....")
		
		
	def print_osoba(self):
		print(f"dane osoby -> imię: {self.imie}, wiek: {self.wiek}, waga: {self.waga} kg, wzrost: {self.wzrost} cm")
		
	def wiekza10lat(self):
		return self.wiek + 10
	
	def czypracownik(self):
		return False
		
		
p1 = Osoba("Jan",14,56,168)
p1.kolor_oczu = "piwne"
print(f"kolor oczu: {p1.kolor_oczu}")
p1.print_osoba()
print(f"wiek za 10 lat: {p1.wiekza10lat()} lat/a")
print(f"czy osoba jest pracownikiem? {p1.czypracownik()}")
print("*******************************************")
p2 = Osoba("Anna",88,64,166)
print(f"kolor oczu: {p2.kolor_oczu}")
p2.print_osoba()
print(f"wiek za 10 lat: {p2.wiekza10lat()} lat/a")
print(f"czy osoba jest pracownikiem? {p2.czypracownik()}")

#dziedziczenie klasy Osoba przez nową klasę Pracownik
class Pracownik(Osoba):
	
	#konstruktor z dziedziczeniem
	def __init__(self,imie,wiek,waga,wzrost,firma,stanowisko,placa,latapracy):
		super().__init__(imie,wiek,waga,wzrost)
		self.firma = firma
		self.stanowisko = stanowisko
		self.placa = placa
		self.latapracy = latapracy
		
	def print_pracownik(self):
		print(f"dane pracownika -> firma: {self.firma}, stanowisko: {self.stanowisko}, płaca: {self.placa} zł"
		      f", lata pracy: {self.latapracy}")
		
	def czypracownik(self):
		return True
		
print("************************************************")
em1 = Pracownik("Karol",55,118,176,"ABC","dyrektor",8900,12)
print(f"kolor oczu: {em1.kolor_oczu}")
em1.print_osoba()
em1.print_pracownik()
print(f"wiek za 10 lat: {em1.wiekza10lat()} lat/a")
print(f"czy osoba jest pracownikiem? {em1.czypracownik()}")