x = lambda a:a+16

print(x(5))
print(x(1.7545))

def wara(a):
	return a+16

#wynik x jest tożsamy z return funkcji wara()

print(wara(6))

y = lambda a,b,c=2:a+b*c

print(y(9,3,4))
print(y(9,3))

def multi(n):
	return lambda a:a*n

d = multi(6)
print(d(9))
print(multi(12)(3))

#zastosowanie lambda do filtrowania listy

liczby = [1,2,4,5,7,8,10,9,11,21,24,26,89,90,101,120,2030,2111]

parzyste = list(filter(lambda x:x%2==0, liczby))
print(parzyste)

#zastosowanie lambda do mapowania listy

cube = list(map(lambda x:pow(x,3),liczby))
print(cube)

# def cb(x:int)->int:
# 	return x**3
#
# #print(type(cb(4)))
# cube = list(map(cb(x),liczby))
# print(cube)