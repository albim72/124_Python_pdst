#funkcja kwota -> (transport+nocleg_wyzywienie)*(1-rabat)+wycieczki+ubezpieczenie+inne

def kwota(t,nw,w,u,i,rab=0):
    return (nw+t)*(1-rab/100)+w+u+i

print(kwota(100,100,50,50,50),"zł")
print(kwota(100,100,50,50,50,25),"zł")

rabs = [0,8,10,12,15,20,25]

#dla rabatu 0 wypisz -> kwota bazowa wynosi: kwota
#dla rabatów pozostałych -> dla rabatu x% kwota do zapłaty wynosi: kwota

#dodatkowo: zapisz kwoty które policzyliśmy dla każdego rabatu do tablicy wynik =[]

wynik = []
for r in rabs:
    kw = kwota (1700, 1230, 450, 200, 180, r)

    if r == 0:
        print ("cena bazowa do zapłaty wynosi:", kw, "zł")
        wynik = wynik + [kw]
    else:
        print ("dla rabatu: ", r, "%, kwota do zapłaty wynosi:", kw, "zł")
        wynik = wynik + [kw]

print (wynik)
result = [kwota(1700,1230,450,200,180,r) for r in rabs]
print(result)

#wersja w pętli z input()
#zadaj rabat 5 pocent na start
#w pętli while postaw warunek rabatu mniejszego równego niż 50% i dokonaj przerwania programu w stuacji gdy
#1. rabat będzie równy 0 lub mniejszy
#2. rabat będzie większy od 50%
# w pętli za pomocą funckji input() zadawaj wartości rabatu aż do usykania warunku przerwania

rab = 5

while rab<=50:
    rab= float(input("podaj rabat:"))
    if rab <= 0:
        break

    if rab > 50:
        break
    kw = kwota(1700, 1230, 450, 200, 180, rab)
    print(kw)