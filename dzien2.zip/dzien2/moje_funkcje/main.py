def witaj():
	print("witaj użytkowniku")
	print("zapłać za abonament")
	print("zaloguj się....")
	
witaj()
witaj()
#wykonaj 25 razy funkcję witaj()

for i in range(25):
	witaj()
	print(i)
	
	
#funkcja z parametrem

def obywatel(nrtelefonu,kraj="Polska"):
	print("pochodzę z kraju:",kraj,", numer telefonu:",nrtelefonu)
	
obywatel(46345343,"Rosja")
obywatel(56546565,"Norwegia")
obywatel(45635465,"Kanada")
obywatel(27886767)


def fx(x,y):
	return x**y

f = 10
def oblicz(a,b,x):
	global f
	global gx
	def gx(x):
		return 2*x
	
	f = (a+b)*x + f + fx(a,b) - gx(x)
	return f

d1 = int(input("podaj wartość a:"))
d2 = int(input("podaj wartość b:"))
d3 = int(input("podaj wartość x:"))
print(oblicz(d1,d2,d3))
print(f)

print(fx(9,4))
print(gx(True))

#funkcja z parametrami domyślnymi
def miasta(miasto3,miasto2="Radom",miasto1="Kraków"):
	print("miasto tygodnia: ",miasto1,", drugie miejsce: ",miasto2,", trzecie miejsce: ",miasto3,sep="")
	
miasta("Katowice","Lublin","Wrocław")
miasta("Katowice","Lublin")
miasta("Katowice")
miasta("Toruń",None,"Gdańsk")
miasta("Toruń",miasto1="Gdańsk")
miasta(miasto1="Gdańsk",miasto3="Toruń")

#funkcja z listą parametrów
#zm = ["Ogrodzieniec","Chojnik","Czersk"]
def zamki(*zamek,rabat):
	print(" zamek tygodnia: ",zamek[0],", drugie miejsce: ",zamek[1],", rabat = ",rabat,"zł",sep="")
	
	
zamki("Malbork","Czersk","Będzin",rabat=40)
zamki("Janowiec","Malbork","Chojnik","Czersk","Będzin",rabat=8)


