ultra = {
	"nazwa_biegu":"Winter Trail Małopolska",
	"rodzaj":"biegi ultra",
	"dystans":45
}

print(ultra)

ultra["limit_czasu"] = 12
print(ultra)

print(ultra["limit_czasu"])

#print kluczy
print("***********************")
for bieg in ultra:
	print(bieg)

print("***********************")
for bieg in ultra:
	print(ultra[bieg])
	
print("***********************")


print(ultra.items())
for klucz,wart in ultra.items():
	print(klucz,":",wart)
print("*****************************")
print(klucz)
print(ultra.keys())

zawody = {
	
	1:{
		"nazwa_biegu": "Winter Trail Małopolska",
		"rodzaj": "biegi ultra",
		"dystans": 45,
		"limit_czasu": 12
	},
	2:{
		"nazwa_biegu": "Gorce Ultra Trail",
		"rodzaj": "biegi ultra",
		"dystans": 48,
		"limit_czasu": 10
	},
	3:{
		"nazwa_biegu": "Bieg na Kasprowy",
		"rodzaj": "skyrunning",
		"dystans": 9,
		"limit_czasu": 2
	},
	4:["Lubomierz","Ochotnica","Zakopane"]
}

print(zawody)
for b in zawody.values():
	print(b)
	
print(zawody[1]["nazwa_biegu"],", miejsce:",zawody[4][0])