wiek = 36
dane = "nazywam się Janek i mam {} lat"
print(dane.format(wiek))

miasto = "Lublin"
wiek = 24
imie = "Olga"
info = "dane klienta -> miasto: {}, wiek: {}, imię: {}."
print(info.format(miasto,wiek,imie))

info = "dane klienta -> imię: {2}, wiek: {1}, miasto: {0}."
print(info.format(miasto,wiek,imie))

#fstring
info = f"dane studenta -> imię: {imie}, miasto: {miasto}"
print(info)

id = "cena"
kwota = 12.6789

formatowanie = '%-30s = %.2f' %(id,kwota)
print(formatowanie)

owoce = [
	('awokado',7.99),
	('banan',4.99),
	('mandarynka',9.99),
	('jabłko',3.53),
	('kiwi',21.55)
]

#cennik -> #nr: nazwa = x.xx zł
print("**********************************")
for i,(item,count) in enumerate(owoce):
	print('#%d: %-10s = %-5.2f zł' %(i,item,count))
print ("**********************************")

for i,(item,count) in enumerate(owoce):
	print('#%d: %-10s = %-5.2f zł' %(
		i+1,
		item.title(),
		round(count,1)
	))
print ("**********************************")
