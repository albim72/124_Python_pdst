class Kolor:
	
	paleta = "paleta X"
	
	#opis stanu -> konstruktor klasy
	def __init__(self,id,nazwa):
		self.id = id #self.nazwazmiennej = nazwaparametru
		self.nazwakoloru = nazwa
		
	#opis zachowania ->  funkcje klasy (metody)

	def print_kolor(self):
		print(f"id koloru: {self.id}, nazwa: {self.nazwakoloru}, paleta: {self.paleta}")
		
	
k1 = Kolor(23,"czerwony")
k2 = Kolor(3,"czarny")

k1.print_kolor()
k2.print_kolor()

print(k1)
print(type(k1))