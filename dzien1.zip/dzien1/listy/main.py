lista = ["Polak","Rosjanin","Niemiec","Francuz"]
print(lista)
print(type(lista))
lista.append("Turek")
print(lista)
lista.sort()
print(lista)
lista.reverse()
print(lista)

liczby = [2,56,78,112,0,-2,112,99,4,15,-34,13,16,0,116]

liczby.reverse()
print(liczby)

liczby.sort(reverse=True)

#[] - lierał listy, jest również używany przy deklaracji numeru indeksu wybranego elementu
print(liczby)

liczby.remove(4)
print(liczby)

del liczby[4:7]
print(liczby)

liczby[3:6] = [67,1001,4567,-999,0,112]

print(liczby)

liczby[8] = 10000
print(liczby)

liczby.insert(2,15900)
print(liczby)

sklepzoo = [["pies","kot","papuga","mysz","szynszyla"],[6000,1400,7800,45,120]]

print(sklepzoo[0])
print(sklepzoo[0][0])
print(sklepzoo[1][3])
print(sklepzoo[0][3],"-",sklepzoo[1][3],"zł")

miasto = ["Toruń","Gliwice","Lublin","Rzeszów"]
stolica = ["Moskwa","Warszawa","Londyn"]
miasta = miasto + stolica
print(miasta)
print(stolica)
print(miasto)

stolica = stolica + ["Rzym","Tokyo"]
print(stolica)
stolica = stolica*4
print(stolica)


litery = ['a','b','c','d','e','f','g','h']
litery_m = litery
litery_p = litery
litery_n1 = list(litery)
litery_n2 = litery[:] #new list
print("litery przed zmianą:",litery)
print("litery_m przed zmianą:",litery_m)
litery[2:7] = [99,24,56]
print("litery po zmianie:",litery)
assert litery is litery_m
print("litery_m po zmianie:",litery_m)
litery_p[:] = [True,False,True,True]
print("litery po zmianie:",litery)
print("litery_m po zmianie:",litery_m)
print("litery_p po zmianie:",litery_p)
print("litery_n1 po zmianie:",litery_n1)
print("litery_n2 po zmianie:",litery_n2)

a = 2
b = a

a = 10

print(a,b)

kolory = ['czerwony','zielony','czarny','biały','niebieski']

#stwórz dwie tablice (parz i nieparz) tak aby do jednej z nich wstawić elementy o indeksach parzystych (plus zero), a
# do drugiej o indeksach nieparzystych

parz = kolory[::2]
nieparz = kolory[1::2]

print(parz)
print(nieparz)

w1 = "kajak"
w2 = "pomarańcza"

#wypisz wyrazy od końca

we1 = w1[::-1]
we2 = w2[::-1]
print(we1)
print(we2)


