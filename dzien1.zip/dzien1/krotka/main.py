#krotka = tuple
animal = ("pies","kot","papuga","królik","szczur","pies")
print(animal)
print(animal[1:4])
for a in animal:
	print(a)
print(animal.index("kot"))
print(animal.count("pies"))
if "papuga" in animal:
	print("Tak! Papuga to zwierz!")
if "budynek" in animal:
	print("Błąd! usuń element!")
else:
	print("budynek to nie zwierz i go nie ma w tej krotce....")
	
print(len(animal))
anim2 = ("pająk","ryba")
animal = animal + anim2
print(animal)
a3 = ["jeż","koza"]
animal = animal + tuple(a3)
print(animal)
ob = ["obiekt67",67,1001,0.56,"Toruń",True,1]
#przekształć list w krotkę
mojakrotka = tuple(ob)
#dodaj do krotki na pozycji 3 wartość 100,
#usuń z krotki wartość 67
#zamień wartość "Toruń" na "Kraków"
#dodaj na ostatniej pozycji wartość False
#mojalista na podstawie mojakrotka
#na liście wykonaj operacje i z powrotem nadpisz mojakrotka
mojalista = list(mojakrotka)
mojalista.insert(3,100)
mojalista.remove(67)
n = mojalista.index("Toruń")
mojalista[n] = "Kraków"
mojalista.append(False)

mojakrotka = tuple(mojalista)
print(mojakrotka)

auto = (34,"Audi","Q7",3.8,2018,78900)
(id,marka,model,poj,rok,przebieg) = auto
print(id)
print(marka)
print(model)
print(poj)
print(rok)
print(przebieg)