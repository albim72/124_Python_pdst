drzewa = {"buk","dąb","jesion","baobab","jabłoń","świerk"}

print(drzewa)
print(drzewa)
print(drzewa)

print("****************************************")
for d in drzewa:
	print(d)
print("****************************************")
j = "jesion" in drzewa
print(j)
print("osika" in drzewa)

drzewa.add("osika")
print(drzewa)

drzewa.update(["wierzba","topola","sosna"])
print(drzewa)

drzewa.update({"różeniec"})
print(drzewa)

drzewa.remove("różeniec")
print(drzewa)

drzewa.discard("jojoba")
print(drzewa)

drzewa.discard("świerk")
print(drzewa)

las = list(drzewa)
print(las)

del las[2:5]
drzewa = set(las)
print(drzewa)

drzewa_m = drzewa.pop()
print(drzewa_m)
print(drzewa)





