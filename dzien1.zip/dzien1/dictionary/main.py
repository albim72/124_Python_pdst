#słownik => dict => (klucz,wartość)

auto = {
	"marka":"Ford",
	"model":"Mustang",
	"rok":1972
}

print(auto)
print(type(auto))

m = auto["model"]
print(m)
auto["rok"] = 2019


print(auto)
print(auto.items())
print(auto.keys())
print(auto.values())