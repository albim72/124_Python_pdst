a = 22
b = 22

if a < b:
    print("a < b")
elif a == b:
    print("a = b")
else:
    print("a > b")
    
#if- elif - else
#od wersji 3.10 match case
#iteracja
#dwa rodzaje: while,for
i = 1
while i<6:
    print(i)
    # if i==3:
    #     break
    i += 1
else:
    print("wartość i wynosi:",i)
    
owoce = ["jabłko","wiśnia","banan","kiwi"]
for owoc in owoce:
    print(owoc)
   
cechy = ["kolorowy","brudny","kosztowny"]
obiekty = ["przystanek","ogród","płaszcz",1001]

for cecha in cechy[:2]:
    for obiekt in obiekty[2:]:
        print(cecha,obiekt)
       


    
    
    
