print("to jest prosty program")
a = 89
print(a)
print(type(a))

a = "jeden"
print(a)
print(type(a))

#komentarz
#zakomentowanie/odkomentowanie bloku tekstu -> CTRl + /

f:float
f= 0.99
print(f)
print(type(f))

f= 772
print(f)
print(type(f))

#powielenie linii (musisz stać na końcu linii) -> CTRL+D
print(3*f)
print(3-f)
print(f/45)

s1 = "pora roku: jesień"
s2 = "pora roku: zima"

print(s1,s2,sep=", ")
print(s1+", a nastpna " + s2)

y = "16.55"
print(y)
print(y*8)

print(float(y)*8)
print(eval(y)*8)

g1 = 10
g2 = 11

print(g1+g2, g1-g2, g1*g2, g1/g2, g1%g2)
print(round(10.51,1))
print(pow(5,2))
print(5**2)
u =19
u += 1
print(u)

t = "lajkonik"
print(t)
print(t[0])
print(t[3])
print(t[2:5])
print(t[:4])
print(t[3:])

print(t[-1])
print(t[:len(t)-2])

