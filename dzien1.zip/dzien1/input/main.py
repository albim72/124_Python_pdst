print("podaj swoje imię: ")

imie = input()
print("miło Cię widzieć:",imie)
print("liczb znaków imienia:",len(imie))

wiek = int(input("podaj swój wiek: "))
print("za 10 lat twój wiek to: " + str(wiek+10) + " lat")